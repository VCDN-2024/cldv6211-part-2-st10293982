﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using System.CodeDom;

namespace WebApplication1.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AppRolesController : Controller
    {
        private readonly RoleManager<IdentityRole> _roleManager;

        public AppRolesController(RoleManager<IdentityRole> roleManager)
        {
            _roleManager = roleManager;
        }

        //List of all the Roles Created by uses
        public IActionResult Index()
        {
            var roles = _roleManager.Roles;
            return View(roles);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        //public async Task<IActionResult> Create(IdentityRole model)
        //{
        //    if (!_roleManager.RoleExistsAsync(model.Name).GetAwaiter().GetResult()) 
        //    {
        //    _roleManager.CreateAsync(new IdentityRole(model.Name)).GetAwaiter().GetResult();

        //    }
        //    return RedirectToAction("Index");
        //}
        public async Task<IActionResult> Create(IdentityRole model)
        {
            if (model == null || string.IsNullOrWhiteSpace(model.Name))
            {
                ModelState.AddModelError("", "Role name cannot be null or empty.");
                return View(model);
            }

            if (!await _roleManager.RoleExistsAsync(model.Name))
            {
                var role = new IdentityRole(model.Name);
                var result = await _roleManager.CreateAsync(role);

                if (result.Succeeded)
                {
                    // Role created successfully, you can redirect to a suitable page.
                    return RedirectToAction("Index");
                }
                else
                {
                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }
                }
            }
            else
            {
                ModelState.AddModelError("", "Role already exists.");
            }

            return View();
        }

    }
}
