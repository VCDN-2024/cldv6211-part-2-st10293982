﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    public class ProductController : Controller
    {
        public ActionResult Index()
        {
            // Ideally, product details would be fetched from a database
            var products = new List<Product>
            {
                new Product { Id = 1, Name = "Eco-Friendly Artisan Crate Chair", Price = 500, ImageUrl = "~/images/9b042c_ca42427b01314c01b0901ad7314a708e_mv2.jpg", Description = "Made from reclaimed wooden crates, combines sustainability with rustic charm. It's durably crafted, stylish, and supports a green lifestyle, making it an ideal addition to any home or office looking for comfort and eco-conscious design." },
                new Product { Id = 2, Name = "Sustainable Wood Countertop", Price = 1500, ImageUrl = "~/images/butternut-wood-countertop.img_-1.jpg", Description = "The perfect blend of natural beauty and eco-friendly design. Crafted from reclaimed wood, each countertop is unique, showcasing the rich textures and patterns of its origins. Durable and versatile, it's ideal for any kitchen or workspace looking to add a touch of warmth and sustainability. Elevate your space with our countertop that combines practicality with environmental responsibility." },
                new Product { Id = 3, Name = "Artisan Crate Chair 2.0", Price = 700, ImageUrl = "~/images/guest_2fb62eb7-cc90-4a1b-9edd-4e957d5eb5d6.jpg", Description = "Made from reclaimed wooden crates, combines sustainability with rustic charm. It's durably crafted, stylish, and supports a green lifestyle, making it an ideal addition to any home or office looking for comfort and eco-conscious design." },
                new Product { Id = 4, Name = "Small Birdhouse", Price = 500, ImageUrl = "~/images/timeless-multi-species-bird-house-03.jpg", Description = "A cozy retreat for your feathered friends crafted from sustainably sourced wood. Its compact design is perfect for small spaces, offering a safe haven for birds to nest and thrive. With its natural finish and sturdy construction, this birdhouse blends seamlessly into any outdoor space, providing a touch of rustic charm while promoting biodiversity. Invite nature into your garden with our environmentally friendly and adorable small birdhouse." }
            };

            return View(products);
        }

        public ActionResult Details1(int id)
        {
            // Fetch the product details from the database based on the product id
            var product = new Product
            {
                Id = id,
                Name = "Product Name",
                Price = 500,
                ImageUrl = "~/images/product.jpg",
                Description = "Product description here."
            };

            return View(product);
        }
        public ActionResult Details2(int id)
        {
            // Fetch the product details from the database based on the product id
            var product = new Product
            {
                Id = id,
                Name = "Product Name",
                Price = 500,
                ImageUrl = "~/images/product.jpg",
                Description = "Product description here."
            };

            return View(product);
        }
        public ActionResult Details3(int id)
        {
            // Fetch the product details from the database based on the product id
            var product = new Product
            {
                Id = id,
                Name = "Product Name",
                Price = 500,
                ImageUrl = "~/images/product.jpg",
                Description = "Product description here."
            };

            return View(product);
        }
        public ActionResult Details4(int id)
        {
            // Fetch the product details from the database based on the product id
            var product = new Product
            {
                Id = id,
                Name = "Product Name",
                Price = 500,
                ImageUrl = "~/images/product.jpg",
                Description = "Product description here."
            };

            return View(product);
        }



        public class Product
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public int Price { get; set; }
            public string ImageUrl { get; set; }
            public string Description { get; set; }
        }
    }

}
